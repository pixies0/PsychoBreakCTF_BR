import subprocess
import sys
import os


arquivo = open("random.dic", "r")

chaves = arquivo.readlines()

for palavra in chaves:
	palavra = str(palavra.replace("\n", ""))
	print(palavra)
	subprocess.run(["./program", palavra])

